package co.edu.ecosistemas.twt.jedi.thewizardstroubles;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class MainActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler{


    private ZXingScannerView mScannerview;
    private Button scan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

scan = findViewById(R.id.BtnScan);




    }

    public  void BtnScan (View v){
        mScannerview = new ZXingScannerView(this);
        setContentView(mScannerview);
        mScannerview.setResultHandler(this);
        mScannerview.startCamera();
        mScannerview.startCamera();

    }



    @Override
    public void handleResult(com.google.zxing.Result result) {

        Log.v("HandleResult", result.getText());
        String mensaje = result.getText();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);



        mScannerview.resumeCameraPreview(this);

        if(mensaje.equals("generico")){
            Intent i = new Intent(MainActivity.this,Main2Activity.class);
            startActivity(i);
        }

        if(mensaje.equals("minijuego1")){
            Intent i = new Intent(MainActivity.this,NivelUno.class);
            startActivity(i);
        }



    }
}
