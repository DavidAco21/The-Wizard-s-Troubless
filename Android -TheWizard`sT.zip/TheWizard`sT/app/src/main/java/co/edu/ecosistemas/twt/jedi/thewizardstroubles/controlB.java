package co.edu.ecosistemas.twt.jedi.thewizardstroubles;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

class controlB extends AppCompatActivity implements View.OnClickListener{

    private Button left,right,up,down, shoot, gen;
    private DatagramSocket socket;
    private String mensaje = "";
    private String palabra;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_uno);


        left = findViewById(R.id.btn_left_cb);
        right = findViewById(R.id.btn_der_cb);
        up = findViewById(R.id.btn_up_cb);
        down = findViewById(R.id.btn_down_cb);
        shoot= findViewById(R.id.btn_dispara_cb);
        gen = findViewById(R.id.btn_gen_cb);



        new Thread(new Runnable() {

            public void run() {

                try {

                    socket = new DatagramSocket(5000);

                    while (true) {




                        byte[] buf = new byte[1024];
                        DatagramPacket packetRecived = new DatagramPacket(buf, buf.length);
                        socket.receive(packetRecived);
                        final String data = new String(packetRecived.getData()).trim();

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(controlB.this, data, Toast.LENGTH_SHORT).show();


                            }
                        });


                    }
                } catch (SocketException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }

        }).start();

        left.setOnClickListener(this);
        right.setOnClickListener(this);
        up.setOnClickListener(this);
        down.setOnClickListener(this);
        shoot.setOnClickListener(this);
        gen.setOnClickListener(this);




    }

    @Override
    public void onClick(View view) {


        if(view.equals(left)){

            palabra = "left";
            mensaje = palabra;
            Log.e("error",mensaje);

        }

        if(view.equals(right)){

            palabra = "right";
            mensaje = palabra;
            Log.e("error",mensaje);

        }
        if(view.equals(up)){

            palabra = "up";
            mensaje = palabra;
            Log.e("error",mensaje);

        }
        if(view.equals(down)){

            palabra = "down";
            mensaje = palabra;
            Log.e("error",mensaje);

        }

        if(view.equals(shoot)){

            palabra = "shoot";
            mensaje = palabra;
            Log.e("error",mensaje);

        }

        if(view.equals(gen)){

            Intent i = new Intent(controlB.this, controlUno.class);
            startActivity(i);

        }




        new Thread(new Runnable() {

            @Override
            public void run() {

                try {
                    String data = mensaje;
                    int length = data.getBytes().length;
                    InetAddress ip;
                    ip = InetAddress.getByName("192.168.1.83");

                    int puerto = 5000;

                    DatagramPacket packet = new DatagramPacket(mensaje.getBytes(), mensaje.getBytes().length, ip, puerto);
                    try {
                        socket.send(packet);
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                } catch (UnknownHostException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }

        }).start();



    }




}
