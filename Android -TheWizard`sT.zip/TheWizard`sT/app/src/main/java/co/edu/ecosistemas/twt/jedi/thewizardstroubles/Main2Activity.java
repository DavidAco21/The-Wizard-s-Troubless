package co.edu.ecosistemas.twt.jedi.thewizardstroubles;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Main2Activity extends AppCompatActivity {

    FirebaseAuth auth;
    FirebaseDatabase db;
    private EditText nombre;
    private EditText correo;
    private EditText contrasena;
    private Button registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

         auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();

        nombre = findViewById(R.id.edt_nombre_main);
        correo = findViewById(R.id.edt_correo_main);
        contrasena = findViewById(R.id.edt_contrasena_main);
        registrar = findViewById(R.id.btn_registrar_main);



        /*auth.createUserWithEmailAndPassword("juanda.bravo98@gmail.com", "jasjasjas").addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Usuario usuario = new Usuario(auth.getCurrentUser().getUid(),"Juan", "juanda.bravo98@gmail.com", "jasjasjas");
                db.getReference().child("Usuarios").child(auth.getCurrentUser().getUid()).setValue(usuario);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });*/

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.createUserWithEmailAndPassword(correo.getText().toString(), contrasena.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Usuario usuario = new Usuario(auth.getCurrentUser().getUid(), nombre.getText().toString(), correo.getText().toString(), contrasena.getText().toString());
                        db.getReference().child("Usuarios").child(auth.getCurrentUser().getUid()).setValue(usuario);
                        Log.e("Alfa", "Está enviando");
                    }
                });

                String[] datos = new String[2];
                datos[0] = correo.getText().toString();
                datos[1] = contrasena.getText().toString();

                Intent i = new Intent(Main2Activity.this, controlUno.class);
                i.putExtra("Usuario", datos);
                startActivity(i);
            }
        });
    }
}
